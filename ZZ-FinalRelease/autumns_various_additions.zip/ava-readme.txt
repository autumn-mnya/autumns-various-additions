# Autumn's Various Additions #

Autumn's Various Additions is a dll featuring many, many new features into Cave Story.

Please read all of the readmes in the Autumnal Lab download, as there is too much to put here.

I will probably update this eventually.

# MERGING YOUR NPC.TBL FILES #

Periwinkle made a helpful python script that will let you merge your old npc.tbl with this new one, which will let you have all of the new npcs in your npc table.

Open the python script, and follow the instructions.
Drag your npc.tbl, and then the "ava-npc.tbl".
You're going to want to pick Option 2, as that merges them together.

You'll need to do this in the future if I add new entities!

Name your new npc.tbl, and save. (Example: Input "new-npc.tbl" to create a file called "new-npc.tbl".