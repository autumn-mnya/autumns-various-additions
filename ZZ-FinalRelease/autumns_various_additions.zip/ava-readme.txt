# Autumn's Various Additions #

Autumn's Various Additions is a dll featuring many, many new features into Cave Story.

A rundown of the features are as follows:

# NEW ENTITIES #

There are new entities in this dll! You can read about them in the Autumnal Lab's Custom Entities txt file.

If you wish to use them, I would advise copying over the "ava-npc.tbl" and replacing your npc.tbl file. This means replacing any stats applied in the Booster's Lab "Edit npc.tbl" window though, obviously.
Currently I have no way around this ^, but I am looking into it :3, i just want to go ahead and get a pre-release version out there first ..

# NEW MOVEMENT #

In the settings.ini file for this mod, you can enable new movement styles in the options! This includes adding a wall jump, a permanent double jump, and a run button into your mod!

# Credits #

Brayconn / Periwinkle - Lots of code help